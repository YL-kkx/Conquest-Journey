![煤粉](item:betterwithmods:material@18)

![木炭粉](item:betterwithmods:material@37)

煤粉和木炭粉用[磨盘](../blocks/millstone.md)制作 ，并且可以用来作[下界煤](nether_coal.md)和[熔魂钢](soulforged_steel.md)的材料。
